import React from "react";
import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  ResponsiveContainer
} from "recharts";

const BudgetChart = ({ total, budget }) => {
  const data = [
    { name: "Spent", value: total },
    { name: "Remaining", value: Math.max(budget - total, 0) },
  ];

  const COLORS = ["#3b82f6", "#e5e7eb"];

  return (
    <div style={{ height: 220 }}>
      <ResponsiveContainer>
        <PieChart>
          <Pie data={data} dataKey="value" innerRadius={60} outerRadius={80}>
            {data.map((entry, index) => (
              <Cell key={index} fill={COLORS[index]} />
            ))}
          </Pie>
          <Tooltip />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
};

export default BudgetChart;