import { Navigate, useLocation } from "react-router-dom";

const ProtectedRoute = ({ children, roleRequired }) => {
  const token = sessionStorage.getItem("token");
  const forceReset = sessionStorage.getItem("forceReset");
  const role = sessionStorage.getItem("role");
  const location = useLocation();

  // ❌ Not logged in
  if (!token) {
    return <Navigate to="/login" replace />;
  }

  // 🔥 FORCE RESET FLOW
  if (forceReset === "true" && location.pathname !== "/reset-password") {
    return <Navigate to="/reset-password" replace />;
  }

  // 🔥 ADMIN CHECK
  if (roleRequired && role !== roleRequired) {
    return <Navigate to="/dashboard" replace />;
  }

  return children;
};

export default ProtectedRoute;