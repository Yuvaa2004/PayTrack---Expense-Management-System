import React from "react";
import "./admin.css";

const DashboardCards = ({ dashboard }) => {

    const cards = [

        {
            title: "Total Users",
            value: dashboard.totalUsers,
            icon: "👤",
            className: "users-card"
        },

        {
            title: "Active Users",
            value: dashboard.activeUsers,
            icon: "🟢",
            className: "active-card"
        },

        {
            title: "Inactive Users",
            value: dashboard.inactiveUsers,
            icon: "🔴",
            className: "inactive-card"
        },

        {
            title: "Admins",
            value: dashboard.totalAdmins,
            icon: "👑",
            className: "admin-card"
        }

    ];

    return (

        <div className="dashboard-cards">

            {

                cards.map((card,index)=>(

                    <div
                        key={index}
                        className={`dashboard-card ${card.className}`}
                    >

                        <div className="card-icon">

                            {card.icon}

                        </div>

                        <div className="card-info">

                            <h3>

                                {card.title}

                            </h3>

                            <h1>

                                {card.value}

                            </h1>

                        </div>

                    </div>

                ))

            }

        </div>

    );

};

export default DashboardCards;