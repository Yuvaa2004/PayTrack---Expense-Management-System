import React, { useMemo, useState } from "react";
import "./admin.css";

const UserTable = ({
    users,
    onActivate,
    onDeactivate
}) => {

    const [search, setSearch] = useState("");

    const filteredUsers = useMemo(() => {

        return users.filter(user =>

            user.username
                .toLowerCase()
                .includes(search.toLowerCase())

            ||

            user.email
                .toLowerCase()
                .includes(search.toLowerCase())

        );

    }, [users, search]);

    /* ===========================
       FORMAT LAST LOGIN
    =========================== */

    const formatLastLogin = (date) => {

        if (!date)
            return "Never Logged In";

        return new Date(date).toLocaleString();
    };

    /* ===========================
       DAYS SINCE LOGIN
    =========================== */

    const getDaysSinceLogin = (date) => {

        if (!date)
            return "Never Logged In";

        const loginDate = new Date(date);

        const today = new Date();

        const diff = today - loginDate;

        const days = Math.floor(
            diff / (1000 * 60 * 60 * 24)
        );

        if (days === 0)
            return "Today";

        if (days === 1)
            return "1 Day Ago";

        return `${days} Days Ago`;
    };

    return (

        <div className="user-table-container">

            <div className="table-header">

                <input

                    className="search-box"

                    type="text"

                    placeholder="🔍 Search by Name or Email"

                    value={search}

                    onChange={(e) =>
                        setSearch(e.target.value)
                    }

                />

            </div>

            <table className="user-table">

                <thead>

                    <tr>

                        <th>Name</th>

                        <th>Email</th>

                        <th>Status</th>

                        <th>Last Login</th>

                        <th>Inactive Since</th>

                        <th>Action</th>

                    </tr>

                </thead>

                <tbody>

                    {

                        filteredUsers.length === 0 ?

                            (

                                <tr>

                                    <td
                                        colSpan="6"
                                        className="empty-row"
                                    >

                                        No Users Found

                                    </td>

                                </tr>

                            )

                            :

                            (

                                filteredUsers.map(user => (

                                    <tr key={user.id}>

                                        <td>

                                            {user.username}

                                        </td>

                                        <td>

                                            {user.email}

                                        </td>

                                        <td>

                                            {

                                                user.active ?

                                                    (

                                                        <span
                                                            className="status active"
                                                        >

                                                            🟢 Active

                                                        </span>

                                                    )

                                                    :

                                                    (

                                                        <span
                                                            className="status inactive"
                                                        >

                                                            🔴 Deactivated

                                                        </span>

                                                    )

                                            }

                                        </td>

                                        <td>

                                            {formatLastLogin(
                                                user.lastLogin
                                            )}

                                        </td>

                                        <td>

                                            {getDaysSinceLogin(
                                                user.lastLogin
                                            )}

                                        </td>

                                        <td>

                                            {

                                                user.active ?

                                                    (

                                                        <button

                                                            className="deactivate-btn"

                                                            onClick={() =>

                                                                onDeactivate(user.id)

                                                            }

                                                        >

                                                            Deactivate

                                                        </button>

                                                    )

                                                    :

                                                    (

                                                        <button

                                                            className="activate-btn"

                                                            onClick={() =>

                                                                onActivate(user.id)

                                                            }

                                                        >

                                                            Activate

                                                        </button>

                                                    )

                                            }

                                            {/*

                                            FUTURE FEATURE

                                            Allow deactivate only after
                                            30 days.

                                            const diff =
                                            (new Date() -
                                            new Date(user.lastLogin))
                                            /(1000*60*60*24);

                                            disabled={diff<30}

                                            */}

                                        </td>

                                    </tr>

                                ))

                            )

                    }

                </tbody>

            </table>

        </div>

    );

};

export default UserTable;