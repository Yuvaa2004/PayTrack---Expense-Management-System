import React from "react";
import {
  PieChart, Pie, Cell, Tooltip,
  LineChart, Line, XAxis, YAxis,
  CartesianGrid, ResponsiveContainer,
  BarChart, Bar
} from "recharts";

import { motion } from "framer-motion";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";

import "../dashboard.css";

const COLORS = ["#6366f1", "#22c55e", "#f59e0b", "#ef4444", "#06b6d4"];

const Report = ({ data, expenses }) => {

  /* ================= DATA ================= */

  const totalExpense = expenses.reduce((sum, e) => sum + e.amount, 0);
  const remaining = data.budget - totalExpense;

  const categoryData = Object.keys(data.categoryWise).map((key) => ({
    name: key,
    value: data.categoryWise[key],
  }));

  const lineData = expenses.map((e) => ({
    name: new Date(e.date).toLocaleDateString(),
    amount: e.amount,
  }));

  /* ================= MONTHLY ================= */

  const getMonth = (date) => new Date(date).getMonth();
  const currentMonth = new Date().getMonth();
  const prevMonth = currentMonth - 1;

  let currentTotal = 0;
  let prevTotal = 0;

  expenses.forEach((e) => {
    const m = getMonth(e.date);
    if (m === currentMonth) currentTotal += e.amount;
    else if (m === prevMonth) prevTotal += e.amount;
  });

  const monthlyCompareData = [
    { name: "Last Month", amount: prevTotal },
    { name: "This Month", amount: currentTotal },
  ];

  /* ================= PDF (FIXED FOR CHARTS) ================= */

  const downloadPDF = async () => {
    const element = document.getElementById("report-section");

    const canvas = await html2canvas(element, {
      scale: 2,
      useCORS: true
    });

    const imgData = canvas.toDataURL("image/png");

    const pdf = new jsPDF("p", "mm", "a4");

    const imgWidth = 210;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;

    pdf.text("PayTrack Report", 10, 10);
    pdf.addImage(imgData, "PNG", 0, 20, imgWidth, imgHeight);

    pdf.save("PayTrack_Report.pdf");
  };

  /* ================= EXCEL EXPORT ================= */

  const downloadExcel = () => {
    const excelData = expenses.map((e) => ({
      Category: e.category,
      Amount: e.amount,
      Date: new Date(e.date).toLocaleDateString(),
      Description: e.description || "",
    }));

    const worksheet = XLSX.utils.json_to_sheet(excelData);
    const workbook = XLSX.utils.book_new();

    XLSX.utils.book_append_sheet(workbook, worksheet, "Expenses");

    const excelBuffer = XLSX.write(workbook, {
      bookType: "xlsx",
      type: "array",
    });

    const dataBlob = new Blob([excelBuffer], {
      type: "application/octet-stream",
    });

    saveAs(dataBlob, "Expenses_Report.xlsx");
  };

  return (
    <motion.div id="report-section" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>

      {/* BUTTONS */}
      <div style={{ display: "flex", justifyContent: "flex-end", gap: "10px", marginBottom: "20px" }}>
        <button className="btn btn-green" onClick={downloadPDF}>
          Download PDF
        </button>

        <button className="btn btn-green" onClick={downloadExcel}>
          Download Excel
        </button>
      </div>

      {/* SUMMARY */}
      <div className="grid grid-4">
        {[
          { label: "Total Expense", value: totalExpense, color: "red" },
          { label: "Budget", value: data.budget, color: "blue" },
          { label: "Remaining", value: remaining, color: "green" }
        ].map((item, i) => (
          <div key={i} className="card">
            <p>{item.label}</p>
            <h2 style={{ color: item.color }}>₹{item.value}</h2>
          </div>
        ))}
      </div>

      {/* CHARTS */}
      <div className="grid grid-2" style={{ marginTop: "20px" }}>

        {/* PIE */}
        <div className="card">
          <h3>Category Breakdown</h3>
          <div className="chart-container">
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie data={categoryData} dataKey="value" label>
                  {categoryData.map((entry, index) => (
                    <Cell key={index} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* LINE */}
        <div className="card">
          <h3>Expense Trend</h3>
          <div className="chart-container">
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={lineData}>
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <CartesianGrid stroke="#ccc" />
                <Line type="monotone" dataKey="amount" stroke="#6366f1" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

      {/* MONTHLY */}
      <div className="card" style={{ marginTop: "20px" }}>
        <h3>Monthly Comparison</h3>

        <div className="chart-container">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={monthlyCompareData}>
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <CartesianGrid stroke="#eee" />
              <Bar dataKey="amount" fill="#22c55e" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* CATEGORY LIST */}
      <div className="card" style={{ marginTop: "20px" }}>
        <h3>Category Wise</h3>

        {categoryData.map((c) => (
          <div key={c.name} style={{
            display: "flex",
            justifyContent: "space-between",
            padding: "8px 0",
            borderBottom: "1px solid #eee"
          }}>
            <span>{c.name}</span>
            <span>₹{c.value}</span>
          </div>
        ))}
      </div>

    </motion.div>
  );
};

export default Report;