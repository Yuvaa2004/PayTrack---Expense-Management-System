import React from "react";
import { Link } from "react-router-dom";
import "../dashboard.css";

const Sidebar = () => {
  return (
    <div className="sidebar">

      <Link to="/">Dashboard</Link>
      <Link to="/expenses">Expenses</Link>
      <Link to="/categories">Categories</Link>
      <Link to="/reset-password">Reset Password</Link>

    </div>
  );
};

export default Sidebar;