import React from "react";
import Navbar from "./Navbar";
import Sidebar from "./Sidebar";
import "../dashboard.css";

const Layout = ({ children }) => {
  return (
    <div>
      <Navbar />

      <div className="layout">
        <Sidebar />

        <div className="content">
          {children}
        </div>
      </div>
    </div>
  );
};

export default Layout;