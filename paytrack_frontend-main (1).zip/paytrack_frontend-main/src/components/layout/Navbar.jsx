import React from "react";
import { useContext } from "react";
import { AuthContext } from "../../context/AuthContext";
import "../dashboard.css";

const Navbar = () => {
  const { logout } = useContext(AuthContext);

  return (
    <div className="navbar">
      <div className="navbar-title">PayTrack</div>

      <button onClick={logout} className="logout-btn">
        Logout
      </button>
    </div>
  );
};

export default Navbar;