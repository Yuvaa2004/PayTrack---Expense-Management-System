import React from "react";
import { useState } from "react";
import { toast } from "react-toastify";
import api from "../../api/axiosInstance";

const AddCategory = ({ onAdd }) => {
  const [form, setForm] = useState({
    name: "",
    type: "",
    description: "",
  });

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validation
    if (!form.name) {
      toast.warning("Category name is required ⚠️");
      return;
    }

    try {
      await api.post("/categories", form);

      // ✅ SUCCESS TOAST
      toast.success("Category added successfully ✅");

      setForm({
        name: "",
        type: "",
        description: "",
      });

      onAdd();

    } catch (err) {
      console.error(err);

      // ❌ ERROR TOAST
      toast.error("Error adding category ❌");
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex gap-2">

      <input
        placeholder="Name"
        className="border p-2 rounded"
        value={form.name}
        onChange={(e) =>
          setForm({ ...form, name: e.target.value })
        }
      />

      <input
        placeholder="Type"
        className="border p-2 rounded"
        value={form.type}
        onChange={(e) =>
          setForm({ ...form, type: e.target.value })
        }
      />

      <input
        placeholder="Description"
        className="border p-2 rounded"
        value={form.description}
        onChange={(e) =>
          setForm({ ...form, description: e.target.value })
        }
      />

      <button className="bg-green-600 text-white px-4 rounded">
        Add
      </button>
    </form>
  );
};

export default AddCategory;