import React from "react";
import { useState } from "react";
import api from "../../api/axiosInstance";
import "../../pages/dashboard.css";

const getIcon = (name) => {
  const n = name.toLowerCase();

  if (n.includes("food")) return "🍔";
  if (n.includes("transport")) return "🚗";
  if (n.includes("movie") || n.includes("entertainment")) return "🎬";
  if (n.includes("utility")) return "💡";
  if (n.includes("shopping")) return "🛒";
  if (n.includes("travel")) return "✈️";

  return "📦";
};

const CategoryCard = ({ category, onSelect, onDelete }) => {
  const [showConfirm, setShowConfirm] = useState(false);

  const spent = category.total || 0;
  const limit = category.limit || 1000;
  const count = category.expenseCount || 0;

  const percent = Math.min((spent / limit) * 100, 100);

  const handleDelete = async () => {
    try {
      await api.delete(`/categories/${category.id}`);
      onDelete();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="category-card">

      {/* HEADER */}
      <div className="card-header">
        <div className="icon">{getIcon(category.name)}</div>
        <h4>{category.name}</h4>
      </div>

      {/* INFO */}
      <p className="spent-text">
        ₹{spent} / ₹{limit}
      </p>

      <p className="count-text">
        {count} expenses
      </p>

      {/* PROGRESS */}
      <div className="progress">
        <div
          className="progress-fill blue"
          style={{ width: `${percent}%` }}
        />
      </div>

      {/* BUTTONS */}
      <div className="card-buttons">
        <button
          className="btn-add"
          onClick={() => onSelect(category)}  // ✅ FIX HERE
        >
          + Add
        </button>

        <button
          className="btn-delete"
          onClick={() => setShowConfirm(true)}
        >
          Delete
        </button>
      </div>

      {/* DELETE CONFIRM */}
      {showConfirm && (
        <div className="modal-overlay">
          <div className="modal small">
            <h4>Delete Category?</h4>
            <p>This cannot be undone.</p>

            <div className="modal-actions">
              <button
                className="btn-delete"
                onClick={handleDelete}
              >
                Yes Delete
              </button>

              <button
                className="btn-cancel"
                onClick={() => setShowConfirm(false)}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

export default CategoryCard;