
// AIChatModal.jsx
// NOTE:
// Replace YOUR_API_KEY with import.meta.env.VITE_GEMINI_API_KEY or your own key.
// This component is intentionally self-contained.

import { useState, useEffect, useRef } from "react";
import "./ai.css";

const API_KEY = import.meta.env.VITE_GEMINI_API_KEY;

export default function AIChatModal({
  expenses = [],
  categories = [],
  budget = 0,
  user = {},
  onClose,
}) {
  const [message, setMessage] = useState("");
  const [chat, setChat] = useState([]);
  const [loading, setLoading] = useState(false);
  const endRef = useRef(null);

  useEffect(() => {
    const saved = localStorage.getItem("ai_chat_history");
    if (saved) {
      setChat(JSON.parse(saved));
    } else {
      setChat([
        {
          role: "bot",
          text: "👋 Hello! I'm PayTrack AI. Ask me anything about your expenses, budget, reports, or how to use the application.",
        },
      ]);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("ai_chat_history", JSON.stringify(chat));
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chat, loading]);

  const totalSpent = expenses.reduce((s, e) => s + Number(e.amount || 0), 0);
  const remaining = budget - totalSpent;

  const buildPrompt = (question) => `
You are PayTrack AI.

Behave like ChatGPT.
Speak naturally.
Do not force Summary/Tips/Advice.
Use dashboard data only when relevant.

Application features:
- Dashboard
- Expenses
- Categories
- Reports
- Profile
- Admin Dashboard

If user asks how to:
- change phone -> Profile > Edit Profile > Save
- update city -> Profile > Edit Profile
- update budget -> Dashboard
- add expense -> Expenses
- add category -> Categories
- view reports -> Reports

User:
${user.username || "User"}

Budget: ₹${budget}
Spent: ₹${totalSpent}
Remaining: ₹${remaining}

Categories:
${categories.map(c => c.name).join(", ") || "None"}

Expenses:
${expenses.map(e => `${e.category}: ₹${e.amount}`).join("\n") || "None"}

Question:
${question}
`;

  async function sendMessage() {
    if (!message.trim()) return;

    const userText = message.trim();

    setChat(prev => [...prev, { role: "user", text: userText }]);
    setLoading(true);

    try {
      const res = await fetch(
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "X-goog-api-key": API_KEY,
          },
          body: JSON.stringify({
            contents: [
              {
                parts: [
                  {
                    text: buildPrompt(userText),
                  },
                ],
              },
            ],
          }),
        }
      );

      const data = await res.json();

      let reply =
        data?.candidates?.[0]?.content?.parts?.[0]?.text ??
        "Sorry, I couldn't generate a response.";

      reply = reply
        .replace(/\*\*/g, "")
        .replace(/###/g, "")
        .replace(/\*/g, "•");

      setChat(prev => [...prev, { role: "bot", text: reply }]);
    } catch (e) {
      setChat(prev => [
        ...prev,
        {
          role: "bot",
          text: "Sorry, I'm having trouble answering right now.",
        },
      ]);
    }

    setLoading(false);
    setMessage("");
  }

  const clearChat = () => {
    localStorage.removeItem("ai_chat_history");
    setChat([]);
  };

  return (
    <div className="ai-overlay">
      <div className="ai-modal">
        <div className="ai-header">
          <h3>🤖 PayTrack AI</h3>
          <div style={{display:"flex",gap:10}}>
            <button onClick={clearChat}>🗑</button>
            <button onClick={onClose}>✖</button>
          </div>
        </div>

        <div className="ai-chat-box">
          {chat.map((c,i)=>(
            <div key={i} className={`msg ${c.role}`}>
              <div className="bubble">
                {c.text.split("\n").map((l,j)=><p key={j}>{l}</p>)}
              </div>
            </div>
          ))}

          {loading && <div className="typing">AI is thinking...</div>}
          <div ref={endRef}></div>
        </div>

        <div className="ai-input">
          <input
            value={message}
            placeholder="Ask me anything..."
            onChange={e=>setMessage(e.target.value)}
            onKeyDown={e=>{
              if(e.key==="Enter"){
                e.preventDefault();
                sendMessage();
              }
            }}
          />
          <button onClick={sendMessage}>Send</button>
        </div>
      </div>
    </div>
  );
}
