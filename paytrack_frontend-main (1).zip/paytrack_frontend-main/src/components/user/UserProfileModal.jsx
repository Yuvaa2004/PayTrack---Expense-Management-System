import { useEffect, useState } from "react";
import { toast } from "react-toastify";
import api from "../../api/axiosInstance";
import "../dashboard.css";

const UserProfileModal = ({
    isOpen,
    onClose,
    onUpdate,
    user
}) => {

    const [editMode, setEditMode] = useState(false);

    const [form, setForm] = useState({
        phone: "",
        city: "",
        monthlyBudget: "",
        savingsGoal: ""
    });

    const [originalForm, setOriginalForm] = useState({});

    useEffect(() => {

        if (user && isOpen) {

            const profile = {
                phone: user.phone || "",
                city: user.city || "",
                monthlyBudget: user.monthlyBudget || "",
                savingsGoal: user.savingsGoal || ""
            };

            setForm(profile);

            setOriginalForm(profile);

            if (!user.profileCompleted) {
                setEditMode(true);
            } else {
                setEditMode(false);
            }

        }

    }, [user, isOpen]);

    if (!isOpen) return null;

    const handleChange = (field, value) => {

        setForm(prev => ({
            ...prev,
            [field]: value
        }));

    };

    const validate = () => {

        if (!/^\d{10}$/.test(form.phone)) {

            toast.error("Phone number must contain exactly 10 digits.");

            return false;

        }

        if (!form.city.trim()) {

            toast.error("City cannot be empty.");

            return false;

        }

        if (Number(form.monthlyBudget) <= 0) {

            toast.error("Monthly Budget must be greater than zero.");

            return false;

        }

        if (Number(form.savingsGoal) < 0) {

            toast.error("Savings Goal cannot be negative.");

            return false;

        }

        if (
            Number(form.savingsGoal) >
            Number(form.monthlyBudget)
        ) {

            toast.error(
                "Savings Goal cannot be greater than Monthly Budget."
            );

            return false;

        }

        return true;

    };

    const handleSubmit = async (e) => {

        e.preventDefault();

        if (!validate()) return;

        const payload = {};

        if (form.phone !== originalForm.phone) {
            payload.phone = form.phone;
        }

        if (form.city !== originalForm.city) {
            payload.city = form.city;
        }

        if (
            Number(form.monthlyBudget) !==
            Number(originalForm.monthlyBudget)
        ) {
            payload.monthlyBudget = Number(form.monthlyBudget);
        }

        if (
            Number(form.savingsGoal) !==
            Number(originalForm.savingsGoal)
        ) {
            payload.savingsGoal = Number(form.savingsGoal);
        }

        if (Object.keys(payload).length === 0) {

            toast.info("No changes detected.");

            setEditMode(false);

            return;

        }

        try {

            await api.put("/users/update", payload);

            toast.success("Profile Updated Successfully 🎉");

            setOriginalForm(form);

            setEditMode(false);

            if (onUpdate) {

                await onUpdate();

            }

            if (user.profileCompleted) {

                onClose();

            }

        } catch (err) {

            toast.error(
                err.response?.data ||
                "Profile Update Failed"
            );

        }

    };return (

<div className="profile-modal-overlay">

    <div className="profile-modal">

        {/* HEADER */}

        <div className="profile-header">

            <div className="profile-avatar">

                {user?.username?.charAt(0).toUpperCase()}

            </div>

            <div>

                <h2>{user?.username}</h2>

                <p>{user?.email}</p>

            </div>

        </div>

        <hr />

        <form onSubmit={handleSubmit}>

            {/* PHONE */}

            <div className="profile-row">

                <label>📱 Phone Number</label>

                <input

                    type="text"

                    maxLength={10}

                    disabled={!editMode}

                    value={form.phone}

                    onChange={(e)=>

                        handleChange("phone",e.target.value)

                    }

                />

            </div>

            {/* CITY */}

            <div className="profile-row">

                <label>🏙 City</label>

                <input

                    disabled={!editMode}

                    value={form.city}

                    onChange={(e)=>

                        handleChange("city",e.target.value)

                    }

                />

            </div>

            {/* MONTHLY BUDGET */}

            <div className="profile-row">

                <label>💰 Monthly Budget</label>

                <input

                    type="number"

                    min="1"

                    disabled={!editMode}

                    value={form.monthlyBudget}

                    onChange={(e)=>

                        handleChange(

                            "monthlyBudget",

                            e.target.value

                        )

                    }

                />

            </div>

            {/* SAVINGS GOAL */}

            <div className="profile-row">

                <label>🎯 Savings Goal</label>

                <input

                    type="number"

                    min="0"

                    disabled={!editMode}

                    value={form.savingsGoal}

                    onChange={(e)=>

                        handleChange(

                            "savingsGoal",

                            e.target.value

                        )

                    }

                />

            </div>

            <div className="profile-buttons">

                {!editMode ? (

                    <>

                        <button

                            type="button"

                            className="btn btn-blue"

                            onClick={()=>

                                setEditMode(true)

                            }

                        >

                            ✏ Edit Profile

                        </button>

                        <button

                            type="button"

                            className="btn"

                            onClick={onClose}

                        >

                            Close

                        </button>

                    </>

                ) : (

                    <>

                        <button

                            type="button"

                            className="btn"

                            onClick={()=>{

                                setForm(originalForm);

                                setEditMode(false);

                            }}

                        >

                            Cancel

                        </button>

                        <button

                            type="submit"

                            className="btn btn-blue"

                        >

                            💾 Save Changes

                        </button>

                    </>

                )}

            </div>

        </form>

    </div>

</div>

);

};

export default UserProfileModal;