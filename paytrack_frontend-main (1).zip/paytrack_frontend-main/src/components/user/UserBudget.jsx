import { useState } from "react";
import { toast } from "react-toastify";
import api from "../../api/axiosInstance";
import "../dashboard.css";

const UserBudget = ({ onUpdate }) => {

  const [form, setForm] = useState({
    phone: "",
    city: "",
    monthlyBudget: "",
    savingsGoal: "",
  });

  const handleSubmit = async (e) => {

    e.preventDefault();

    // PHONE VALIDATION
    if (!/^\d{10}$/.test(form.phone)) {

      toast.error(
        "Phone must be 10 digits ❌"
      );

      return;
    }

    // EMPTY VALIDATION
    if (
      !form.city ||
      !form.monthlyBudget ||
      !form.savingsGoal
    ) {

      toast.error(
        "All fields are required ❌"
      );

      return;
    }

    try {

      const payload = {

        email: localStorage.getItem("email"),

        phone: form.phone,

        city: form.city,

        monthlyBudget: parseFloat(
          form.monthlyBudget
        ),

        savingsGoal: parseFloat(
          form.savingsGoal
        ),
      };

      console.log(payload);

      await api.put(
        "/users/update",
        payload
      );

      toast.success(
        "Profile updated successfully ✅"
      );

      // REFRESH DASHBOARD DATA
      if (onUpdate) {
        onUpdate();
      }

      // CLEAR FORM
      setForm({
        phone: "",
        city: "",
        monthlyBudget: "",
        savingsGoal: "",
      });

    } catch (err) {

      console.error(err);

      console.log(
        err.response?.data
      );

      toast.error(
        err.response?.data?.message ||
        "Update failed ❌"
      );
    }
  };

  return (

    <div
      className="card"
      style={{ maxWidth: "400px" }}
    >

      <h3 style={{ marginBottom: "10px" }}>
        Update Profile
      </h3>

      <form onSubmit={handleSubmit}>

        <input
          type="text"
          placeholder="Phone"
          maxLength={10}
          value={form.phone}
          onChange={(e) =>
            setForm({
              ...form,
              phone: e.target.value,
            })
          }
        />

        <input
          type="text"
          placeholder="City"
          value={form.city}
          onChange={(e) =>
            setForm({
              ...form,
              city: e.target.value,
            })
          }
        />

        <input
          type="number"
          placeholder="Monthly Budget"
          value={form.monthlyBudget}
          onChange={(e) =>
            setForm({
              ...form,
              monthlyBudget: e.target.value,
            })
          }
        />

        <input
          type="number"
          placeholder="Savings Goal"
          value={form.savingsGoal}
          onChange={(e) =>
            setForm({
              ...form,
              savingsGoal: e.target.value,
            })
          }
        />

        <button
          className="btn btn-blue"
          style={{
            width: "100%",
            marginTop: "10px",
          }}
        >
          Save
        </button>

      </form>

    </div>
  );
};

export default UserBudget;