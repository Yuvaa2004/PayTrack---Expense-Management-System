import React from "react";
import { toast } from "react-toastify";
import Swal from "sweetalert2";
import api from "../../api/axiosInstance";
import "../../pages/dashboard.css";

const getIcon = (name) => {
  const n = name.toLowerCase();
  if (n.includes("food")) return "🍔";
  if (n.includes("sports")) return "🏀";
  if (n.includes("movie")) return "🎬";
  if (n.includes("travel")) return "✈️";
  return "📦";
};

const getColor = (percent) => {
  if (percent < 40) return "green";
  if (percent < 75) return "orange";
  return "red";
};

const ExpenseTable = ({ expenses, refresh }) => {

  const maxAmount = Math.max(...expenses.map(e => e.amount), 1);
  const total = expenses.reduce((sum, e) => sum + e.amount, 0);

  //  DELETE WITH YES / NO POPUP
  const handleDelete = async (id) => {
    const result = await Swal.fire({
      title: "Delete this expense?",
      text: "This action cannot be undone",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes",
      cancelButtonText: "No",
      confirmButtonColor: "#e74c3c",
      cancelButtonColor: "#6c757d"
    });

    if (!result.isConfirmed) return;

    try {
      await api.delete(`/expenses/${id}`);

      // success toast
      toast.success("Deleted successfully 🗑️");

     

      refresh(); // reload data
    } catch (err) {
      console.error(err.response?.data || err);
      toast.error("Failed to delete ❌");
    }
  };

  return (
    <div className="expense-table-card">

      <h2 className="table-title">Recent Expenses</h2>

      <table className="expense-table">

        <thead>
          <tr>
            <th>Category</th>
            <th>Amount</th>
            <th>Date</th>
            <th>Usage</th>
            <th>Action</th>
          </tr>
        </thead>

        <tbody>
          {expenses.map((e) => {

            const percent = (e.amount / maxAmount) * 100;
            const color = getColor(percent);

            return (
              <tr key={e.id}>

                <td className="category-cell">
                  <span className="icon">{getIcon(e.category)}</span>
                  <span>{e.category}</span>
                </td>

                <td className="amount-cell">₹{e.amount}</td>

                <td className="date-cell">{e.date}</td>

                <td>
                  <div className="progress small">
                    <div
                      className={`progress-fill ${color}`}
                      style={{ width: `${percent}%` }}
                    />
                  </div>
                </td>

                <td>
                  <button
                    className="btn-delete"
                    onClick={() => handleDelete(e.id)}
                  >
                    🗑️
                  </button>
                </td>

              </tr>
            );
          })}
        </tbody>

        <tfoot>
          <tr className="total-row">
            <td>Total</td>
            <td>₹{total}</td>
            <td colSpan="3"></td>
          </tr>
        </tfoot>

      </table>

    </div>
  );
};

export default ExpenseTable;