import React, { useState } from "react";
import { toast } from "react-toastify";
import api from "../../api/axiosInstance";
import "../../pages/dashboard.css";

const AddExpense = ({ selectedCategory, onAdd }) => {
  const [form, setForm] = useState({
    amount: "",
    description: "",
    date: ""
  });

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!form.amount || !selectedCategory) {
      toast.warning("Amount & Category required ⚠️");
      return;
    }

    try {
      await api.post("/expenses", {
        category: selectedCategory,
        amount: Number(form.amount),
        description: form.description,
        date: form.date
      });

      toast.success("Expense added 💸");

      setForm({
        amount: "",
        description: "",
        date: ""
      });

      onAdd(); // refresh list
    } catch (err) {
      console.error(err.response?.data || err);
      toast.error("Failed to add expense ❌");
    }
  };

  return (
    <form onSubmit={handleSubmit} className="expense-form">
      <input
        placeholder="Amount"
        className="input"
        value={form.amount}
        onChange={(e) =>
          setForm({ ...form, amount: e.target.value })
        }
      />

      <input
        placeholder="Description"
        className="input"
        value={form.description}
        onChange={(e) =>
          setForm({ ...form, description: e.target.value })
        }
      />

      <input
        type="date"
        className="input"
        value={form.date}
        onChange={(e) =>
          setForm({ ...form, date: e.target.value })
        }
      />

      <button className="btn-primary">
        Save Expense
      </button>
    </form>
  );
};

export default AddExpense;