import axios from "axios";

const api = axios.create({
  baseURL: "http://localhost:8080",
  headers: {
    "Content-Type": "application/json",
  },
});


api.interceptors.request.use(
  (config) => {
    const token = sessionStorage.getItem("token");

    const isAuthRoute =
      config.url.includes("/auth/login") ||
      config.url.includes("/auth/register") ||
      config.url.includes("/auth/forgot-password");
      config.url.includes("/auth/reset-password"); 

    if (token && !isAuthRoute) {
      config.headers.Authorization = `Bearer ${token}`;
      console.log("TOKEN ATTACHED:", config.headers.Authorization);
    } else {
      console.log("NO TOKEN ATTACHED");
    }

    console.log("REQUEST URL:", config.url);

    return config;
  },
  (error) => Promise.reject(error)
);

export default api;