import { useState } from "react";
import api from "../api/axiosInstance";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import "./auth.css";

export default function Register() {
  const [form, setForm] = useState({
    username: "",
    email: "",
    password: "",
  });

  const [errors, setErrors] = useState({});
  const [showPassword, setShowPassword] = useState(false);
  const [strength, setStrength] = useState("");
  const navigate = useNavigate();

  //  Password strength logic
  const checkStrength = (password) => {
    let score = 0;

    if (password.length >= 8) score++;
    if (/[A-Z]/.test(password)) score++;
    if (/[a-z]/.test(password)) score++;
    if (/\d/.test(password)) score++;
    if (/[@#$%^&+=!]/.test(password)) score++;

    if (score <= 2) return "Weak";
    if (score === 3 || score === 4) return "Medium";
    return "Strong";
  };

  const validate = () => {
    let err = {};

    if (!form.username) err.username = "Username required";

    if (!form.email) {
      err.email = "Email required";
    } else if (!/\S+@\S+\.\S+/.test(form.email)) {
      err.email = "Invalid email";
    }

    if (!form.password) {
      err.password = "Password required";
    } 
    else if (form.password.length < 6) {
      err.password = "Minimum 6 characters";
    } 
    else if (
      !/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@#$%^&+=!]).{8,}$/.test(form.password)
    ) {
      err.password =
        "8+ chars, 1 uppercase, 1 lowercase, 1 number, 1 special char";
    }

    setErrors(err);
    return Object.keys(err).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validate()) return;

    try {
      await api.post("/auth/register", form);
      toast.success("Registered successfully ✅");
      navigate("/login");
    } catch (err) {
      const message =
        err.response?.data?.message ||
        err.response?.data ||
        "Registration failed ❌";

      if (message.toLowerCase().includes("username")) {
        setErrors((prev) => ({
          ...prev,
          username: "Username already exists ❌",
        }));
      } else if (message.toLowerCase().includes("email")) {
        setErrors((prev) => ({
          ...prev,
          email: "Email already registered ❌",
        }));
      } else {
        setErrors((prev) => ({
          ...prev,
          api: message,
        }));
      }
    }
  };

  return (
    <div className="auth-container">

      <div className="auth-left">
        <div className="auth-overlay">
          <h1>Join PayTrack</h1>
          <p>Start managing your money</p>
        </div>
      </div>

      <div className="auth-right">
        <div className="auth-card">

          <h2>Register</h2>

          <form onSubmit={handleSubmit} className="auth-form">

            {/* USERNAME */}
            <div className="input-group">
              <input
                placeholder="Username"
                value={form.username}
                onChange={(e) => {
                  setForm({ ...form, username: e.target.value });
                  setErrors((prev) => ({ ...prev, username: "" }));
                }}
                className={errors.username ? "error" : ""}
              />
              {errors.username && <p className="error-text">{errors.username}</p>}
            </div>

            {/* EMAIL */}
            <div className="input-group">
              <input
                type="email"
                placeholder="Email"
                value={form.email}
                onChange={(e) => {
                  setForm({ ...form, email: e.target.value });
                  setErrors((prev) => ({ ...prev, email: "" }));
                }}
                className={errors.email ? "error" : ""}
              />
              {errors.email && <p className="error-text">{errors.email}</p>}
            </div>

            {/* PASSWORD */}
            <div className="input-group">

              <div style={{ position: "relative" }}>
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="Password"
                  value={form.password}
                  onChange={(e) => {
                    const value = e.target.value;
                    setForm({ ...form, password: value });

                    const strengthVal = checkStrength(value);
                    setStrength(strengthVal);

                    // live validation
                    if (
                      !/^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@#$%^&+=!]).{8,}$/.test(value)
                    ) {
                      setErrors((prev) => ({
                        ...prev,
                        password:
                          "8+ chars, 1 uppercase, 1 lowercase, 1 number, 1 special char",
                      }));
                    } else {
                      setErrors((prev) => ({
                        ...prev,
                        password: "",
                      }));
                    }
                  }}
                  className={errors.password ? "error" : ""}
                />

                {/*  TOGGLE */}
                <span
                  onClick={() => setShowPassword(!showPassword)}
                  style={{
                    position: "absolute",
                    right: "10px",
                    top: "50%",
                    transform: "translateY(-50%)",
                    cursor: "pointer",
                    fontSize: "14px",
                  }}
                >
                  {showPassword ? "🙈" : "👁"}
                </span>
              </div>

              {/*  STRENGTH METER */}
              {form.password && (
                <div style={{ marginTop: "5px" }}>
                  <div
                    style={{
                      height: "6px",
                      borderRadius: "5px",
                      background:
                        strength === "Weak"
                          ? "#ef4444"
                          : strength === "Medium"
                          ? "#f59e0b"
                          : "#22c55e",
                      width:
                        strength === "Weak"
                          ? "30%"
                          : strength === "Medium"
                          ? "60%"
                          : "100%",
                      transition: "0.3s",
                    }}
                  />
                  <p
                    style={{
                      fontSize: "12px",
                      color:
                        strength === "Weak"
                          ? "#ef4444"
                          : strength === "Medium"
                          ? "#f59e0b"
                          : "#22c55e",
                    }}
                  >
                    {strength} password
                  </p>
                </div>
              )}

              {/* GREEN CHECK */}
              {!errors.password &&
                form.password &&
                /^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@#$%^&+=!]).{8,}$/.test(
                  form.password
                ) && (
                  <p style={{ color: "#22c55e", fontSize: "12px" }}>
                    ✔ Strong password
                  </p>
                )}

              {errors.password && <p className="error-text">{errors.password}</p>}
            </div>

            {/* API ERROR */}
            {errors.api && <p className="error-text">{errors.api}</p>}

            <button type="submit">Register</button>

          </form>

          <div className="auth-links">
            <p>
              Already have an account?{" "}
              <span onClick={() => navigate("/login")}>
                Login
              </span>
            </p>
          </div>

        </div>
      </div>

    </div>
  );
}