import { useState } from "react";
import api from "../api/axiosInstance";
import "./auth.css";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
const navigate = useNavigate();
  const validate = () => {
    if (!email) {
      setError("Email is required");
      return false;
    }

    if (!/\S+@\S+\.\S+/.test(email)) {
      setError("Invalid email format");
      return false;
    }

    setError("");
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validate()) return;

    try {
      await api.post("/auth/forgot-password", { email });
      toast.success("Reset link sent ✅");
    } catch (err) {
      toast.error("Error sending email ❌");
    }
  };

  return (
    <div className="auth-container">

      <div className="auth-left">
        <div className="auth-overlay">
          <h1>Reset Password</h1>
          <p>We’ll help you recover your account</p>
        </div>
      </div>

      <div className="auth-right">
        <div className="auth-card">

          <h2>Forgot Password</h2>

          <form onSubmit={handleSubmit} className="auth-form">

            <div className="input-group">
              <input
                placeholder="Enter Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className={error ? "error" : ""}
              />
              {error && <p className="error-text">{error}</p>}
            </div>

            <button type="submit">Send Reset Link</button>
<div className="auth-links">
            <p>
              Back To {" "}
              <span onClick={() => navigate("/login")}>
                Login
              </span>
            </p>
          </div>
          </form>

        </div>
      </div>

    </div>
  );
}