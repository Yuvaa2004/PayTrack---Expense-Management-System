import React from "react";
import { useState, useContext } from "react";
import api from "../api/axiosInstance";
import { AuthContext } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import "./auth.css";

const Login = () => {

  const [form, setForm] = useState({
    username: "",
    password: "",
    role: "ROLE_USER",
  });

  const [errors, setErrors] = useState({});

  const { login } = useContext(AuthContext);

  const navigate = useNavigate();

  const validate = () => {

    let err = {};

    if (!form.username.trim()) {
      err.username = "Username is required";
    }

    if (!form.password.trim()) {
      err.password = "Password is required";
    }

    setErrors(err);

    return Object.keys(err).length === 0;
  };

  const handleSubmit = async (e) => {

    e.preventDefault();

    if (!validate()) return;

    try {

      // LOGIN API
      const res = await api.post(
        "/auth/login",
        {
          username: form.username,
          password: form.password,
        }
      );

      const {
        token,
        forcePasswordReset,
        role
      } = res.data;

      if (!token) {
        throw new Error("Token missing");
      }

      // ROLE VALIDATION
      if (role !== form.role) {

        toast.error(
          "Invalid role selected ❌"
        );

        return;
      }

      // STORE TOKEN
      sessionStorage.setItem(
        "token",
        token
      );

      // STORE ROLE
      sessionStorage.setItem(
        "role",
        role
      );

      // STORE RESET FLAG
      sessionStorage.setItem(
        "forceReset",
        forcePasswordReset
      );

      // LOGIN CONTEXT
      login(token);

      // FETCH USER DETAILS
      const userRes = await api.get(
        "/auth/me"
      );

      // STORE EMAIL + USERNAME
      sessionStorage.setItem(
        "email",
        userRes.data.email
      );

      sessionStorage.setItem(
        "username",
        userRes.data.username
      );

      // FORCE RESET
      if (forcePasswordReset) {

        toast.warning(
          "You must reset your password ⚠️"
        );

        navigate("/reset-password");

        return;
      }

      toast.success(
        "Login successful ✅"
      );

      // ROLE BASED NAVIGATION
      if (role === "ROLE_ADMIN") {

        navigate("/admin");

      } else {

        navigate("/dashboard");
      }

    } catch (err) {

      console.error(err);

      const msg =
        err.response?.data?.message ||
        err.response?.data ||
        "";

      if (
        msg.toLowerCase().includes("expired")
      ) {

        toast.error(
          "Temporary password expired ⏳"
        );

      } else if (
        msg.toLowerCase().includes("invalid")
      ) {

        toast.error(
          "Invalid username or password ❌"
        );

      } else {

        toast.error(
          "Login failed ❌"
        );
      }

      setErrors({
        api: "Login failed"
      });
    }
  };

  return (

    <div className="auth-container">

      {/* LEFT */}
      <div className="auth-left">

        <div className="auth-overlay">
          <h1>PayTrack</h1>
          <p>Smart expense tracking</p>
        </div>

      </div>

      {/* RIGHT */}
      <div className="auth-right">

        <div className="auth-card">

          <h2>Login</h2>

          <form
            onSubmit={handleSubmit}
            className="auth-form"
          >

            {/* USERNAME */}
            <div className="input-group">

              <input
                type="text"
                placeholder="Username"
                value={form.username}
                onChange={(e) =>
                  setForm({
                    ...form,
                    username: e.target.value
                  })
                }
              />

              {errors.username && (
                <p className="error-text">
                  {errors.username}
                </p>
              )}

            </div>

            {/* PASSWORD */}
            <div className="input-group">

              <input
                type="password"
                placeholder="Password"
                value={form.password}
                onChange={(e) =>
                  setForm({
                    ...form,
                    password: e.target.value
                  })
                }
              />

              {errors.password && (
                <p className="error-text">
                  {errors.password}
                </p>
              )}

            </div>

            {/* ROLE */}
            <div className="input-group">

              <select
                value={form.role}
                onChange={(e) =>
                  setForm({
                    ...form,
                    role: e.target.value
                  })
                }
              >

                <option value="ROLE_USER">
                  User
                </option>

                <option value="ROLE_ADMIN">
                  Admin
                </option>

              </select>

            </div>

            {/* API ERROR */}
            {errors.api && (
              <p className="error-text">
                {errors.api}
              </p>
            )}

            {/* BUTTON */}
            <button type="submit">
              Login
            </button>

          </form>

          {/* LINKS */}
          <div className="auth-links">

            <span
              onClick={() =>
                navigate("/forgot")
              }
            >
              Forgot Password?
            </span>

            <p>
              New user?{" "}

              <span
                onClick={() =>
                  navigate("/register")
                }
              >
                Register
              </span>

            </p>

          </div>

        </div>

      </div>

    </div>
  );
};

export default Login;