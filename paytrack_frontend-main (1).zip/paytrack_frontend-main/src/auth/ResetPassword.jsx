import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import api from "../api/axiosInstance";
import "./auth.css";

const ResetPassword = () => {
  const [form, setForm] = useState({
    email: sessionStorage.getItem("email") || "",
    password: "",
  });

  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!form.email || !form.password) {
      toast.warning("All fields are required ⚠️");
      return;
    }

    try {
      console.log("Sending reset request:", form);

      await api.post("/auth/reset-password", {
        email: form.email,
        newPassword: form.password,
      });

      toast.success("Password reset successful ✅");

      // cleanup
      sessionStorage.removeItem("forceReset");

      navigate("/dashboard");

    } catch (err) {
      console.log("ERROR:", err.response?.data);

      const msg = err.response?.data?.message || "";

      if (msg.includes("authentication")) {
        toast.error("Backend auth issue ⚠️ (not frontend)");
      } else {
        toast.error("Reset failed ❌");
      }
    }
  };

  return (
  <div className="auth-right">
  <div className="auth-card reset-card animate-fade">

    <div className="reset-icon">🔒</div>

    <h2>Reset Password</h2>
    <p className="reset-subtitle">
      Enter your new password below
    </p>

    <form onSubmit={handleSubmit} className="auth-form reset-form">

      <div className="input-group">
        <input
          type="email"
          placeholder="Email"
          value={form.email}
          onChange={(e) =>
            setForm({ ...form, email: e.target.value })
          }
        />
      </div>

      <div className="input-group">
        <input
          type="password"
          placeholder="New Password"
          value={form.password}
          onChange={(e) =>
            setForm({ ...form, password: e.target.value })
          }
        />
      </div>

      <button type="submit">Reset Password</button>
    </form>

    <div className="reset-divider"></div>

    <div className="reset-back">
      <span onClick={() => navigate("/")}>
        ← Back to Login
      </span>
    </div>

  </div>
</div>
  );
};

export default ResetPassword;