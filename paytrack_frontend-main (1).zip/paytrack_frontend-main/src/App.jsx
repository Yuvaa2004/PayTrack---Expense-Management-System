import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { useEffect, useState } from "react";

// Toast
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

// Pages
import Login from "./auth/Login";
import Register from "./auth/Register";
import ForgotPassword from "./auth/ForgotPassword";
import ResetPassword from "./auth/ResetPassword";

import Dashboard from "./pages/Dashboard";
import ExpensesPage from "./pages/ExpensesPage";
import CategoriesPage from "./pages/CategoriesPage";
import ReportPage from "./pages/ReportPage";
import AdminDashboard from "./pages/AdminDashboard";

// Landing Page
import LandingPage from "./pages/LandingPage";

// Protected Route
import ProtectedRoute from "./components/common/ProtectedRoute";

function App() {

  const [theme, setTheme] = useState("dark");

  useEffect(() => {

    const savedTheme =
      localStorage.getItem("theme") || "dark";

    setTheme(savedTheme);

    document.body.className = savedTheme;

  }, []);

  const toggleTheme = () => {

    const newTheme =
      theme === "dark"
        ? "light"
        : "dark";

    setTheme(newTheme);

    sessionStorage.setItem(
      "theme",
      newTheme
    );

    document.body.className =
      newTheme;
  };

  // GET ROLE FROM LOCAL STORAGE
  const role =
    sessionStorage.getItem("role");

  return (

    <BrowserRouter>

      {/* TOAST */}
      <ToastContainer
        position="top-right"
        autoClose={2500}
        theme={theme}
      />

      <Routes>

        {/* LANDING PAGE */}
        <Route
          path="/"
          element={
            role
              ? role === "ROLE_ADMIN"
                ? <Navigate to="/admin" />
                : <Navigate to="/dashboard" />
              : (
                <LandingPage
                  toggleTheme={toggleTheme}
                  theme={theme}
                />
              )
          }
        />

        {/* PUBLIC ROUTES */}
        <Route
          path="/login"
          element={<Login />}
        />

        <Route
          path="/register"
          element={<Register />}
        />

        <Route
          path="/forgot"
          element={<ForgotPassword />}
        />

        <Route
          path="/reset-password"
          element={<ResetPassword />}
        />

        {/* USER DASHBOARD */}
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          }
        />

        {/* REPORT */}
        <Route
          path="/report"
          element={
            <ProtectedRoute>
              <ReportPage />
            </ProtectedRoute>
          }
        />

        {/* EXPENSES */}
        <Route
          path="/expenses"
          element={
            <ProtectedRoute>
              <ExpensesPage />
            </ProtectedRoute>
          }
        />

        {/* CATEGORIES */}
        <Route
          path="/categories"
          element={
            <ProtectedRoute>
              <CategoriesPage />
            </ProtectedRoute>
          }
        />

        {/* ADMIN DASHBOARD */}
        <Route
          path="/admin"
          element={
            <ProtectedRoute
              roleRequired="ROLE_ADMIN"
            >
              <AdminDashboard />
            </ProtectedRoute>
          }
        />

        {/* FALLBACK */}
        <Route
          path="*"
          element={<Navigate to="/" />}
        />

      </Routes>

    </BrowserRouter>
  );
}

export default App;