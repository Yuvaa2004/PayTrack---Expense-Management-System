import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";
import Layout from "../components/layout/Layout";
import DashboardCards from "../components/admin/DashboardCards";
import UserTable from "../components/admin/UserTable";
import api from "../api/axiosInstance";
import "./admin.css";

const AdminDashboard = () => {

    const [dashboard, setDashboard] = useState({

        totalUsers: 0,

        activeUsers: 0,

        inactiveUsers: 0,

        totalAdmins: 0

    });

    const [users, setUsers] = useState([]);

    const [loading, setLoading] = useState(true);

    useEffect(() => {

        loadDashboard();

    }, []);

    const loadDashboard = async () => {

        try {

            const [dashboardRes, usersRes] = await Promise.all([

                api.get("/admin/dashboard"),

                api.get("/admin/users")

            ]);

            setDashboard(dashboardRes.data);

            setUsers(usersRes.data);

        }

        catch (err) {

            console.error(err);

            toast.error("Failed to load admin dashboard.");

        }

        finally {

            setLoading(false);

        }

    };

    const activateUser = async (id) => {

        try {

            await api.put(`/admin/users/${id}/activate`);

            toast.success("User Activated");

            loadDashboard();

        }

        catch (err) {

            toast.error("Unable to activate user");

        }

    };

    const deactivateUser = async (id) => {

        try {

            await api.put(`/admin/users/${id}/deactivate`);

            toast.success("User Deactivated");

            loadDashboard();

        }

        catch (err) {

            toast.error("Unable to deactivate user");

        }

    };

    if (loading) {

        return (

            <Layout>

                <h2 style={{padding:"40px"}}>

                    Loading Admin Dashboard...

                </h2>

            </Layout>

        );

    }

    return (

        <Layout>

            <div className="admin-dashboard">

                <h1>

                    Admin Dashboard

                </h1>

                <DashboardCards

                    dashboard={dashboard}

                />

                <div className="admin-users-card">

                    <h2>

                        User Management

                    </h2>

                    <UserTable

                        users={users}

                        onActivate={activateUser}

                        onDeactivate={deactivateUser}

                    />

                </div>

            </div>

        </Layout>

    );

};

export default AdminDashboard;