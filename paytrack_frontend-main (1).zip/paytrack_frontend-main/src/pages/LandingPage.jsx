import React from "react";
import { useNavigate } from "react-router-dom";
import "./landing.css";

const LandingPage = ({ toggleTheme, theme }) => {
  const navigate = useNavigate();

  return (
    <div className="landing">

      {/* NAVBAR */}
      <nav className="navbar glass">
        <h2>💰 PayTrack</h2> 

        <div>
          <button onClick={() => navigate("/login")} className="btn outline">
            Login
          </button>
          <button onClick={() => navigate("/register")} className="btn primary">
            Get Started
          </button>

          <button onClick={toggleTheme} className="theme-btn">
            {theme === "dark" ? "🌞" : "🌙"}
          </button>
        </div>
      </nav>

      {/* HERO */}
      <div className="hero">
        <div>
          <h1>Manage Your Money Smarter 🚀</h1>
          <p>
            Track expenses, set budgets, and achieve financial freedom with PayTrack.
          </p>

          <button className="btn primary" onClick={() => navigate("/register")}>
            Start Free
          </button>
        </div>

        <div className="card glass">
          <h3>📊 Real-Time Analytics</h3>
          <p>Visualize your expenses instantly.</p>
        </div>
      </div>

      {/* FEATURES */}
      <div className="features">
        <div className="card glass">⚡ Fast Tracking</div>
        <div className="card glass">🧠 Manage Your Expenses Smartly</div>
        <div className="card glass">📈 Smart Reports</div>
      </div>
    </div>
  );
};

export default LandingPage;