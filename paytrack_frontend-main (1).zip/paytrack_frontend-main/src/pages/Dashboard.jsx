import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

import Layout from "../components/layout/Layout";
import AddCategory from "../components/categories/AddCategory";
import CategoryCard from "../components/categories/CategoryCard";
import AddExpense from "../components/expenses/AddExpense";
import ExpenseTable from "../components/expenses/ExpenseTable";
import BudgetChart from "../components/charts/BudgetChart";
import AIChatModal from "../components/AIChatModal";
import UserProfileModal from "../components/user/UserProfileModal";

import api from "../api/axiosInstance";
import "./dashboard.css";

const Dashboard = () => {

    const navigate = useNavigate();

    const [user, setUser] = useState(null);

    const [expenses, setExpenses] = useState([]);

    const [categories, setCategories] = useState([]);

    const [selectedCategory, setSelectedCategory] = useState("");

    const [budget, setBudget] = useState(0);

    const [goal, setGoal] = useState(0);

    const [totalExpense, setTotalExpense] = useState(0);

    const [showProfile, setShowProfile] = useState(false);

    const [showExpenseModal, setShowExpenseModal] = useState(false);

    const [showAI, setShowAI] = useState(false);

    useEffect(() => {

        loadDashboard();

    }, []);

    const loadDashboard = async () => {

        try {

            const [
                userRes,
                expenseRes,
                categoryRes
            ] = await Promise.all([
                api.get("/users/me"),
                api.get("/expenses/my"),
                api.get("/categories/my")
            ]);

            const userData = userRes.data;

            setUser(userData);

            setBudget(userData.monthlyBudget);

            setGoal(userData.savingsGoal);

            if (!userData.profileCompleted) {

                setShowProfile(true);

            }

            const expenses = expenseRes.data;

            const categories = categoryRes.data;

            const total = expenses.reduce(
                (sum, e) => sum + e.amount,
                0
            );

            setExpenses(expenses);

            setTotalExpense(total);

            const updatedCategories = categories.map(cat => {

                const filtered = expenses.filter(
                    e => e.category === cat.name
                );

                const amount = filtered.reduce(
                    (sum, e) => sum + e.amount,
                    0
                );

                return {

                    ...cat,

                    total: amount,

                    expenseCount: filtered.length

                };

            });

            setCategories(updatedCategories);

        }

        catch (err) {

            console.error(err);

            toast.error("Unable to load dashboard.");

        }

    };

    const refreshProfile = async () => {

        try {

            const res = await api.get("/users/me");

            setUser(res.data);

            setBudget(res.data.monthlyBudget);

            setGoal(res.data.savingsGoal);

        }

        catch (err) {

            console.error(err);

        }

    };

return (

<Layout>

<div className="dashboard">

    {/* ================= HEADER ================= */}

    <div className="top-header">

        <div>

            <h2 className="logo">💰 PayTrack</h2>

            <p className="welcome-text">

                Welcome Back,

                <span className="username">

                    {user?.username || "User"}

                </span>

            </p>

        </div>

        <div className="profile-menu">

            <div className="profile-btn">

                <div className="profile-avatar-small">

                    {user?.username
                        ?.charAt(0)
                        ?.toUpperCase()}

                </div>

                <div>

                    <strong>

                        {user?.username}

                    </strong>

                    <small>

                        {user?.email}

                    </small>

                </div>

            </div>

            <div className="dropdown">

                <div
                    onClick={() =>
                        setShowProfile(true)
                    }
                >

                    👤 My Profile

                </div>

                <div
                    onClick={() =>
                        navigate("/report")
                    }
                >

                    📄 Reports

                </div>

                <div
                    onClick={() => {

                        sessionStorage.clear();

                        navigate("/login");

                    }}
                >

                    🚪 Logout

                </div>

            </div>

        </div>

    </div>

    {/* ================= PROFILE MODAL ================= */}

    <UserProfileModal

        isOpen={showProfile}

        user={user}

        onClose={() => {

            if (user?.profileCompleted) {

                setShowProfile(false);

            }

        }}

        onUpdate={async () => {

            await refreshProfile();

            await loadDashboard();

            setShowProfile(false);

        }}

    />

    {/* ================= SUMMARY ================= */}

    <div className="top-bar">

        <div className="top-item">

            <p>💰 Monthly Budget</p>

            <h3>

                ₹{budget}

            </h3>

        </div>

        <div className="top-item">

            <p>💸 Total Expenses</p>

            <h3>

                ₹{totalExpense}

            </h3>

        </div>

        <div className="top-item">

            <p>🏦 Remaining Budget</p>

            <h3>

                ₹{budget-totalExpense}

            </h3>

        </div>

        <div className="top-item">

            <p>🎯 Savings Goal</p>

            <h3>

                ₹{goal}

            </h3>

        </div>

    </div>

    {/* ================= GRID ================= */}

    <div className="dashboard-grid">

        {/* ================= LEFT ================= */}

        <div>

            <div className="card">

                <h3>

                    Budget Utilization

                </h3>

                <BudgetChart

                    total={totalExpense}

                    budget={budget}

                />

            </div>

            <h3
                className="section-title"
            >

                Expense Categories

            </h3>

            <div className="category-grid">

                {

                    categories.map(cat=>(

                        <CategoryCard

                            key={cat.id}

                            category={cat}

                            onSelect={(category)=>{

                                setSelectedCategory(

                                    category.name

                                );

                                setShowExpenseModal(

                                    true

                                );

                            }}

                            onDelete={()=>{

                                loadDashboard();

                            }}

                        />

                    ))

                }

            </div>

        </div>

        {/* ================= RIGHT ================= */}

        <div className="right-section">

            <div className="card">

                <h3>

                    Create Category

                </h3>

                <AddCategory

                    onAdd={()=>{

                        loadDashboard();

                        toast.success(

                            "Category Added"

                        );

                    }}

                />

            </div>

            <div className="card">

                <h3>

                    Expense History

                </h3>

                <ExpenseTable

                    expenses={expenses}

                    onRefresh={loadDashboard}

                />

            </div>

        </div>

    </div>
        {/* ================= ADD EXPENSE MODAL ================= */}

        {

            showExpenseModal && (

                <div className="modal-overlay">

                    <div className="modal">

                        <h2>Add Expense</h2>

                        <AddExpense

                            selectedCategory={selectedCategory}

                            onAdd={() => {

                                loadDashboard();

                                setShowExpenseModal(false);

                                toast.success(
                                    "Expense Added Successfully 💸"
                                );

                            }}

                        />

                        <button

                            className="btn"

                            onClick={() =>
                                setShowExpenseModal(false)
                            }

                        >

                            Close

                        </button>

                    </div>

                </div>

            )

        }

        {/* ================= FLOATING REPORT BUTTON ================= */}

        <div

            className="floating-btn"

            onClick={() =>
                navigate("/report")
            }

        >

            📄

        </div>

        {/* ================= FLOATING AI BUTTON ================= */}

        <div

            className="ai-float-btn"

            onClick={() =>
                setShowAI(true)
            }

        >

            🤖

        </div>

        {/* ================= AI MODAL ================= */}

        {

            showAI && (

                <AIChatModal

                    expenses={expenses}

                    categories={categories}

                    budget={budget}

                    onClose={() =>
                        setShowAI(false)
                    }

                />

            )

        }

</div>

</Layout>

);

};

export default Dashboard;