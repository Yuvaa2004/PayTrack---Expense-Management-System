import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/axiosInstance";
import "../pages/dashboard.css";

const getIcon = (name) => {
  if (!name || typeof name !== "string") return "📦";

  const n = name.toLowerCase();

  if (n.includes("food")) return "🍔";
  if (n.includes("sports")) return "🏀";
  if (n.includes("movie")) return "🎬";
  if (n.includes("travel")) return "✈️";

  return "📦";
};

const CategoriesPage = () => {
  const [categories, setCategories] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    loadCategories();
  }, []);

  const loadCategories = async () => {
    try {
      const res = await api.get("/categories/my");
      setCategories(res.data || []);
    } catch (err) {
      console.error(err);
      setCategories([]);
    }
  };

  return (
    <div className="page">

      {/* 🔙 Back Button */}
      <button className="back-btn" onClick={() => navigate(-1)}>
        ← Back
      </button>

      <h2 className="page-title">My Categories</h2>

      <div className="category-grid">
        {categories?.length > 0 ? (
          categories.map((cat) => (
            <div key={cat?.id} className="category-card">

              <div className="card-header">
                <span className="icon">{getIcon(cat?.name)}</span>
                <h4>{cat?.name || "Unknown"}</h4>
              </div>

              <p className="count-text">{cat?.type || "N/A"}</p>

            </div>
          ))
        ) : (
          <p>No categories found</p>
        )}
      </div>

    </div>
  );
};

export default CategoriesPage;