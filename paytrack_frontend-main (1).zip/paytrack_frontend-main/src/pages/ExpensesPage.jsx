import React, { useEffect, useState } from "react";
import api from "../api/axiosInstance";
import "../pages/dashboard.css";
import ExpenseDonutChart from "../components/charts/ExpenseDonutChart";
import { useNavigate } from "react-router-dom";

const getIcon = (name) => {
  if (!name || typeof name !== "string") return "📦";

  const n = name.toLowerCase();

  if (n.includes("food")) return "🍔";
  if (n.includes("sports")) return "🏀";
  if (n.includes("movie")) return "🎬";
  if (n.includes("travel")) return "✈️";

  return "📦";
};

const ExpensesPage = () => {
  const [expenses, setExpenses] = useState([]);
  const [filtered, setFiltered] = useState([]);
  const navigate = useNavigate();

  const [month, setMonth] = useState("");
  const [category, setCategory] = useState("");

  useEffect(() => {
    loadExpenses();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [expenses, month, category]);

  const loadExpenses = async () => {
    try {
      const res = await api.get("/expenses/my");
      const data = res.data || []; // ✅ safe
      setExpenses(data);
      setFiltered(data);
    } catch (err) {
      console.error(err);
      setExpenses([]);     // ✅ fallback
      setFiltered([]);
    }
  };

  // ✅ SAFE FILTER
  const applyFilters = () => {
    let data = [...expenses];

    if (month) {
      data = data.filter((e) =>
        e?.date ? e.date.startsWith(month) : false
      );
    }

    if (category) {
      data = data.filter((e) => e?.category === category);
    }

    setFiltered(data);
  };

  // ✅ SAFE UNIQUE CATEGORIES
  const categories = [
    ...new Set(expenses.map((e) => e?.category).filter(Boolean)),
  ];

  // ✅ SAFE TOTAL
  const total = filtered.reduce(
    (sum, e) => sum + (e?.amount || 0),
    0
  );

  // ✅ SAFE CATEGORY ANALYTICS
  const categoryMap = {};
  filtered.forEach((e) => {
    const key = e?.category || "Other";
    const amount = e?.amount || 0;

    categoryMap[key] = (categoryMap[key] || 0) + amount;
  });

  const max = Math.max(...Object.values(categoryMap), 1);

  return (
    <div className="page">

      {/* BACK BUTTON */}
      <div className="back-container">
        <button
          onClick={() => navigate("/dashboard")}
          className="back-btn"
        >
          <span className="back-icon">←</span>
          <span>Back</span>
        </button>
      </div>

      <h2 className="page-title">Expenses Analytics</h2>

      {/* FILTERS */}
      <div className="filters">

        <input
          type="month"
          value={month}
          onChange={(e) => setMonth(e.target.value)}
        />

        <select
          value={category}
          onChange={(e) => setCategory(e.target.value)}
        >
          <option value="">All Categories</option>
          {categories.map((c, i) => (
            <option key={i}>{c}</option>
          ))}
        </select>

        <button
          onClick={() => {
            setMonth("");
            setCategory("");
          }}
        >
          Reset
        </button>

      </div>

      {/* TOTAL */}
      <div className="summary-card">
        Total Spend: ₹{total}
      </div>

      {/* ANALYTICS + CHART */}
      <div className="analytics-container">

        {/* LEFT → BARS */}
        <div className="analytics">

          {Object.entries(categoryMap).map(([key, value]) => {
            const percent = (value / max) * 100;

            return (
              <div key={key} className="analytics-row">

                <span>
                  {getIcon(key)} {key}
                </span>

                <div className="progress">
                  <div
                    className="progress-fill blue"
                    style={{ width: `${percent}%` }}
                  />
                </div>

                <span>₹{value}</span>

              </div>
            );
          })}

        </div>

        {/* RIGHT → CHART */}
        <div className="chart-box">
          <ExpenseDonutChart data={categoryMap || {}} />
        </div>

      </div>

      {/* EXPENSE LIST */}
      <div className="expense-grid">

        {filtered.length > 0 ? (
          filtered.map((e) => (
            <div key={e?.id} className="expense-card">

              <div className="expense-top">
                <span>{getIcon(e?.category)}</span>
                <h4>{e?.category || "Unknown"}</h4>
              </div>

              <p className="amount">₹{e?.amount || 0}</p>
              <p className="date">{e?.date || "N/A"}</p>

            </div>
          ))
        ) : (
          <p>No expenses found</p>
        )}

      </div>

    </div>
  );
};

export default ExpensesPage;