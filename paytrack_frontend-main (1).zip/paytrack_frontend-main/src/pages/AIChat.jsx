import { useState } from "react";
import { GoogleGenerativeAI } from "@google/generative-ai";
import "./ai.css";

const genAI = new GoogleGenerativeAI("AIzaSyAaBCum_addeaMUwefERSbTAT0Dvy6RxrA"); 

const model = genAI.getGenerativeModel({
  model: "gemini-1.5-flash",
});

const AIChat = () => {
  const [message, setMessage] = useState("");
  const [chat, setChat] = useState([]);
  const [loading, setLoading] = useState(false);

  const sendMessage = async () => {
    if (!message) return;

    const userMsg = { role: "user", text: message };
    setChat((prev) => [...prev, userMsg]);

    setLoading(true);

    try {
      
      const context = `
      You are a smart financial assistant.
      Help user control budget and reduce expenses.

      Question: ${message}
      `;

      const result = await model.generateContent(context);
      const response = await result.response;
      const text = response.text();

      const botMsg = { role: "bot", text };

      setChat((prev) => [...prev, botMsg]);

    } catch (err) {
      setChat((prev) => [
        ...prev,
        { role: "bot", text: "AI error ❌" },
      ]);
    }

    setLoading(false);
    setMessage("");
  };

  return (
    <div className="ai-container">

      <h3>AI Budget Assistant 🤖</h3>

      <div className="chat-box">
        {chat.map((c, i) => (
          <div key={i} className={c.role}>
            {c.text}
          </div>
        ))}

        {loading && <p>Thinking...</p>}
      </div>

      <div className="chat-input">
        <input
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Ask about your budget..."
        />
        <button onClick={sendMessage}>Send</button>
      </div>

    </div>
  );
};

export default AIChat;