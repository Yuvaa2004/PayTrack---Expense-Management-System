import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Report from "../components/report/Report";
import api from "../api/axiosInstance";

const ReportPage = () => {
  const navigate = useNavigate();

  const currentDate = new Date();

  const [report, setReport] = useState(null);
  const [expenses, setExpenses] = useState([]);
  const [goal, setGoal] = useState(0); 

  const [month, setMonth] = useState(currentDate.getMonth() + 1);
  const [year, setYear] = useState(currentDate.getFullYear());

  // 🔥 LOAD REPORT
  const loadReport = async (m, y) => {
    try {
      const res = await api.get(`/report/monthly?month=${m}&year=${y}`);
      setReport(res.data);
    } catch (err) {
      console.error("Report error:", err);
    }
  };

  // 🔥 LOAD EXPENSES
  const loadExpenses = async () => {
    try {
      const res = await api.get("/expenses/my");
      setExpenses(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  // 🔥 LOAD GOAL (FIX)
  const loadGoal = async () => {
    try {
      const res = await api.get("/goal");
      setGoal(res.data?.amount || 0);
    } catch (err) {
      console.error("Goal error:", err);
      setGoal(0);
    }
  };

  // 🔥 INITIAL LOAD
  useEffect(() => {
    loadReport(month, year);
    loadExpenses();
    loadGoal(); 
  }, []);

  // 🔥 HANDLE MONTH CHANGE
  const handleMonthChange = (e) => {
    const selectedMonth = e.target.value;
    setMonth(selectedMonth);
    loadReport(selectedMonth, year);
  };

  // 🔥 HANDLE YEAR CHANGE
  const handleYearChange = (e) => {
    const selectedYear = e.target.value;
    setYear(selectedYear);
    loadReport(month, selectedYear);
  };

  return (
    <div className="p-6 min-h-screen bg-gray-100 report-container">

      {/* 🔙 Back Button */}
      <button className="back-btn" onClick={() => navigate("/dashboard")}>
        ← Back
      </button>

      {/* HEADER */}
      <div className="flex justify-between items-center mb-6">

        <h1 className="text-2xl font-bold">
          📊 Monthly Report
        </h1>

        {/* FILTERS */}
        <div className="flex gap-3">

          <select
            value={month}
            onChange={handleMonthChange}
            className="border p-2 rounded"
          >
            {[
              "Jan","Feb","Mar","Apr","May","Jun",
              "Jul","Aug","Sep","Oct","Nov","Dec"
            ].map((m, i) => (
              <option key={i} value={i + 1}>
                {m}
              </option>
            ))}
          </select>

          <select
            value={year}
            onChange={handleYearChange}
            className="border p-2 rounded"
          >
            {[2024, 2025, 2026, 2027].map((y) => (
              <option key={y} value={y}>
                {y}
              </option>
            ))}
          </select>

        </div>
      </div>

      {/* REPORT */}
      {report ? (
        <Report data={report} expenses={expenses} goal={goal} />
      ) : (
        <div className="text-center mt-10">
          <p className="text-gray-500">Loading report...</p>
        </div>
      )}

    </div>
  );
};

export default ReportPage;