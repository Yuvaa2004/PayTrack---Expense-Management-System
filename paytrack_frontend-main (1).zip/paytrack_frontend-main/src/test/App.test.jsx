import React from "react";
import { render, screen } from "@testing-library/react";
import { BrowserRouter } from "react-router-dom";
import { describe, it, expect, vi } from "vitest";

import { AuthContext } from "../context/AuthContext";

import Dashboard from "../pages/Dashboard";
import ExpensesPage from "../pages/ExpensesPage";
import CategoriesPage from "../pages/CategoriesPage";
import ReportPage from "../pages/ReportPage";
import AdminDashboard from "../pages/AdminDashboard";

//  MOCK API
vi.mock("../api/axiosInstance", () => ({
  default: {
    get: vi.fn((url) => {

      // USERS (Admin)
      if (url.includes("/users/all")) {
        return Promise.resolve({
          data: [
            { id: 1, username: "TestUser", email: "test@mail.com" },
          ],
        });
      }

      // USER PROFILE
      if (url.includes("/users/me")) {
        return Promise.resolve({
          data: {
            monthlyBudget: 5000,
            savingsGoal: 2000,
          },
        });
      }

      // EXPENSES
      if (url.includes("/expenses")) {
        return Promise.resolve({
          data: [
            { id: 1, category: "Food", amount: 500 },
          ],
        });
      }

      // CATEGORIES
      if (url.includes("/categories")) {
        return Promise.resolve({
          data: [
            { id: 1, name: "Food", type: "EXPENSE" },
          ],
        });
      }

      // REPORT
      if (url.includes("/report")) {
        return Promise.resolve({
          data: {
            total: 500,
            categoryWise: { Food: 500 },
          },
        });
      }

      // 🔥 MISSING ONE → GOAL API (THIS CAUSED ERROR)
      if (url.includes("/goal")) {
        return Promise.resolve({
          data: { goal: 2000 },
        });
      }

      return Promise.resolve({ data: [] });
    }),
  },
}));

//  MOCK CHART (avoid width error)
vi.mock("./components/charts/ExpenseDonutChart", () => ({
  default: () => <div>Chart</div>,
}));

//  MOCK CONTEXT PROVIDER
const MockProvider = ({ children }) => {
  return (
    <AuthContext.Provider
      value={{
        login: vi.fn(),
        logout: vi.fn(),
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

//  REPORT
describe("Report Page", () => {
  it("renders report", async () => {
    render(
      <MockProvider>
        <BrowserRouter>
          <ReportPage />
        </BrowserRouter>
      </MockProvider>
    );

    expect(
      await screen.findByText(/monthly report/i)
    ).toBeInTheDocument();
  });
});


//  ADMIN

describe("Admin Dashboard", () => {
  it("renders admin dashboard", () => {
    render(
      <MockProvider>
        <BrowserRouter>
          <AdminDashboard />
        </BrowserRouter>
      </MockProvider>
    );

    expect(screen.getByText(/admin dashboard/i)).toBeInTheDocument();
  });

  it("shows users", async () => {
    render(
      <MockProvider>
        <BrowserRouter>
          <AdminDashboard />
        </BrowserRouter>
      </MockProvider>
    );

    expect(await screen.findByText(/testuser/i)).toBeInTheDocument();
  });

  it("logout button exists", () => {
    render(
      <MockProvider>
        <BrowserRouter>
          <AdminDashboard />
        </BrowserRouter>
      </MockProvider>
    );

    expect(screen.getByText(/logout/i)).toBeInTheDocument();
  });
});
//  LANDING PAGE
import LandingPage from "../pages/LandingPage";
import { MemoryRouter } from "react-router-dom";

describe("Landing Page", () => {
  it("renders landing page title", () => {
    render(
      <MemoryRouter>
        <LandingPage toggleTheme={() => {}} theme="dark" />
      </MemoryRouter>
    );

    expect(screen.getByRole("heading", { name: /PayTrack/i })).toBeInTheDocument();
  });

  it("renders hero section", () => {
    render(
      <MemoryRouter>
        <LandingPage toggleTheme={() => {}} theme="dark" />
      </MemoryRouter>
    );

    expect(
      screen.getByText(/Manage Your Money Smarter/i)
    ).toBeInTheDocument();
  });

  it("renders feature cards", () => {
    render(
      <MemoryRouter>
        <LandingPage toggleTheme={() => {}} theme="dark" />
      </MemoryRouter>
    );

    expect(screen.getByText(/Fast Tracking/i)).toBeInTheDocument();
    expect(
      screen.getByText(/Manage Your Expenses Smartly/i)
    ).toBeInTheDocument();
    expect(screen.getByText(/Smart Reports/i)).toBeInTheDocument();
  });

  it("calls toggleTheme when clicked", () => {
    const mockToggle = vi.fn();

    render(
      <MemoryRouter>
        <LandingPage toggleTheme={mockToggle} theme="dark" />
      </MemoryRouter>
    );

    const themeBtn = screen.getByRole("button", { name: "🌞" });
    themeBtn.click();

    expect(mockToggle).toHaveBeenCalled();
  });

  it("has login and register buttons", () => {
    render(
      <MemoryRouter>
        <LandingPage toggleTheme={() => {}} theme="dark" />
      </MemoryRouter>
    );

    expect(screen.getByText(/login/i)).toBeInTheDocument();
    expect(screen.getByText(/get started/i)).toBeInTheDocument();
  });
});
