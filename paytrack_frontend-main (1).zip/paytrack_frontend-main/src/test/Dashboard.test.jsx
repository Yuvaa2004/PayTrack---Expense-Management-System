import React from "react";
import {
  render,
  screen,
  fireEvent,
} from "@testing-library/react";

import { MemoryRouter } from "react-router-dom";

import {
  describe,
  it,
  expect,
  vi,
} from "vitest";

import Dashboard from "../pages/Dashboard";

/* ---------------- MOCKS ---------------- */

// API MOCK
vi.mock("../api/axiosInstance", () => ({
  default: {
    get: vi.fn((url) => {

      if (url.includes("/expenses")) {
        return Promise.resolve({
          data: [
            {
              id: 1,
              category: "Food",
              amount: 500,
            },
          ],
        });
      }

      if (url.includes("/categories")) {
        return Promise.resolve({
          data: [
            {
              id: 1,
              name: "Food",
            },
          ],
        });
      }

      if (url.includes("/users")) {
        return Promise.resolve({
          data: {
            monthlyBudget: 5000,
            savingsGoal: 2000,
          },
        });
      }

      return Promise.resolve({
        data: [],
      });
    }),
  },
}));

// LAYOUT MOCK
vi.mock(
  "../components/layout/Layout",
  () => ({
    default: ({ children }) => (
      <div>{children}</div>
    ),
  })
);

// CATEGORY MOCKS
vi.mock(
  "../components/categories/AddCategory",
  () => ({
    default: () => (
      <div>AddCategory</div>
    ),
  })
);

vi.mock(
  "../components/categories/CategoryCard",
  () => ({
    default: ({
      category,
      onSelect,
    }) => (
      <div
        onClick={() =>
          onSelect(category)
        }
      >
        {category.name}
      </div>
    ),
  })
);

// EXPENSE MOCKS
vi.mock(
  "../components/expenses/AddExpense",
  () => ({
    default: () => (
      <div>
        Expense Form Component
      </div>
    ),
  })
);

vi.mock(
  "../components/expenses/ExpenseTable",
  () => ({
    default: () => (
      <div>ExpenseTable</div>
    ),
  })
);

// USER MOCK
vi.mock(
  "../components/user/UserBudget",
  () => ({
    default: () => (
      <div>UserBudget</div>
    ),
  })
);

// CHART MOCK
vi.mock(
  "../components/charts/BudgetChart",
  () => ({
    default: () => (
      <div>BudgetChart</div>
    ),
  })
);

// AI MODAL MOCK
vi.mock(
  "../components/AIChatModal",
  () => ({
    default: ({ onClose }) => (
      <div>
        AI Modal

        <button
          onClick={onClose}
        >
          Close AI
        </button>
      </div>
    ),
  })
);

// NAVIGATION MOCK
const mockNavigate = vi.fn();

vi.mock(
  "react-router-dom",
  async () => {

    const actual =
      await vi.importActual(
        "react-router-dom"
      );

    return {
      ...actual,

      useNavigate: () =>
        mockNavigate,
    };
  }
);

// TOAST MOCK
vi.mock("react-toastify", () => ({
  toast: {
    success: vi.fn(),
    error: vi.fn(),
    info: vi.fn(),
  },
}));

/* ---------------- TESTS ---------------- */

describe("Dashboard", () => {

  it(
    "renders dashboard header",
    async () => {

      render(
        <MemoryRouter>
          <Dashboard />
        </MemoryRouter>
      );

      expect(
        await screen.findByText(
          /PayTrack/i
        )
      ).toBeInTheDocument();
    }
  );

  it(
    "loads and displays category",
    async () => {

      render(
        <MemoryRouter>
          <Dashboard />
        </MemoryRouter>
      );

      expect(
        await screen.findByText(
          /Food/i
        )
      ).toBeInTheDocument();
    }
  );

  it(
    "shows budget values",
    async () => {

      render(
        <MemoryRouter>
          <Dashboard />
        </MemoryRouter>
      );

      expect(
        await screen.findByText(
          /₹5000/i
        )
      ).toBeInTheDocument();

      expect(
        await screen.findByText(
          /₹2000/i
        )
      ).toBeInTheDocument();
    }
  );

  it(
    "opens expense modal when category clicked",
    async () => {

      render(
        <MemoryRouter>
          <Dashboard />
        </MemoryRouter>
      );

      const category =
        await screen.findByText(
          /Food/i
        );

      fireEvent.click(category);

      expect(
        await screen.findByText(
          /Expense Form Component/i
        )
      ).toBeInTheDocument();
    }
  );

  it(
    "opens AI modal",
    async () => {

      render(
        <MemoryRouter>
          <Dashboard />
        </MemoryRouter>
      );

      const aiBtn =
        await screen.findByText(
          "🤖"
        );

      fireEvent.click(aiBtn);

      expect(
        await screen.findByText(
          /AI Modal/i
        )
      ).toBeInTheDocument();
    }
  );

  it(
    "closes AI modal",
    async () => {

      render(
        <MemoryRouter>
          <Dashboard />
        </MemoryRouter>
      );

      fireEvent.click(
        await screen.findByText(
          "🤖"
        )
      );

      fireEvent.click(
        await screen.findByText(
          /Close AI/i
        )
      );

      expect(
        screen.queryByText(
          /AI Modal/i
        )
      ).not.toBeInTheDocument();
    }
  );

  it(
    "navigates to report page",
    async () => {

      render(
        <MemoryRouter>
          <Dashboard />
        </MemoryRouter>
      );

      const btn =
  await screen.findByText(
    "📄 Report"
  );

      expect(
        btn
      ).toBeInTheDocument();

      fireEvent.click(btn);

      expect(
        mockNavigate
      ).toHaveBeenCalledWith(
        "/report"
      );
    }
  );

});