import React from "react";
import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { describe, it, expect, vi, beforeEach } from "vitest";

import ExpensesPage from "../pages/ExpensesPage";
import api from "../api/axiosInstance";

/* ---------------- MOCKS ---------------- */

// API MOCK
vi.mock("../api/axiosInstance", () => ({
  default: {
    get: vi.fn(),
  },
}));

// CHART MOCK
vi.mock("../components/charts/ExpenseDonutChart", () => ({
  default: () => <div data-testid="chart">Mock Chart</div>,
}));

/* ---------------- TEST DATA ---------------- */

const mockExpenses = [
  {
    id: 1,
    category: "Food",
    amount: 500,
    date: "2026-04-10",
  },
  {
    id: 2,
    category: "Travel",
    amount: 1000,
    date: "2026-05-12",
  },
];

/* ---------------- TESTS ---------------- */

describe("ExpensesPage", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    api.get.mockResolvedValue({ data: mockExpenses });
  });

  it("renders page title", async () => {
    render(
      <MemoryRouter>
        <ExpensesPage />
      </MemoryRouter>
    );

    expect(await screen.findByText(/Expenses Analytics/i))
      .toBeInTheDocument();
  });

  it("loads and displays expenses", async () => {
    render(
      <MemoryRouter>
        <ExpensesPage />
      </MemoryRouter>
    );

    expect(await screen.findByRole("heading", { name: "Food" }))
      .toBeInTheDocument();

    expect(await screen.findByRole("heading", { name: "Travel" }))
      .toBeInTheDocument();
  });

  it("shows total spend correctly", async () => {
    render(
      <MemoryRouter>
        <ExpensesPage />
      </MemoryRouter>
    );

    expect(await screen.findByText(/₹1500/i)).toBeInTheDocument();
  });

  it("filters by category", async () => {
    render(
      <MemoryRouter>
        <ExpensesPage />
      </MemoryRouter>
    );

    const select = await screen.findByRole("combobox");

    fireEvent.change(select, { target: { value: "Food" } });

    expect(await screen.findByRole("heading", { name: "Food" }))
      .toBeInTheDocument();

    expect(screen.queryByRole("heading", { name: "Travel" }))
      .not.toBeInTheDocument();
  });

  /* 🔥 FIXED TEST */
  it("filters by month", async () => {
    render(
      <MemoryRouter>
        <ExpensesPage />
      </MemoryRouter>
    );

    const input = document.querySelector('input[type="month"]');

    fireEvent.change(input, { target: { value: "2026-04" } });

    await waitFor(() => {
      expect(screen.getByRole("heading", { name: "Food" }))
        .toBeInTheDocument();

      expect(screen.queryByRole("heading", { name: "Travel" }))
        .not.toBeInTheDocument();
    });
  });

  it("resets filters", async () => {
    render(
      <MemoryRouter>
        <ExpensesPage />
      </MemoryRouter>
    );

    const resetBtn = await screen.findByText(/Reset/i);
    fireEvent.click(resetBtn);

    expect(await screen.findByRole("heading", { name: "Food" }))
      .toBeInTheDocument();

    expect(await screen.findByRole("heading", { name: "Travel" }))
      .toBeInTheDocument();
  });

  it("shows empty state when no data", async () => {
    api.get.mockResolvedValueOnce({ data: [] });

    render(
      <MemoryRouter>
        <ExpensesPage />
      </MemoryRouter>
    );

    expect(await screen.findByText(/No expenses found/i))
      .toBeInTheDocument();
  });

  it("renders chart", async () => {
    render(
      <MemoryRouter>
        <ExpensesPage />
      </MemoryRouter>
    );

    expect(await screen.findByTestId("chart"))
      .toBeInTheDocument();
  });
});