import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { describe, it, expect, vi, beforeEach } from "vitest";

import CategoriesPage from "../pages/CategoriesPage";
import api from "../api/axiosInstance";

/* ---------------- MOCKS ---------------- */

// Mock API
vi.mock("../api/axiosInstance", () => ({
  default: {
    get: vi.fn(),
  },
}));

// Mock useNavigate
const mockNavigate = vi.fn();

vi.mock("react-router-dom", async () => {
  const actual = await vi.importActual("react-router-dom");
  return {
    ...actual,
    useNavigate: () => mockNavigate,
  };
});

/* ---------------- TEST DATA ---------------- */

const mockCategories = [
  { id: 1, name: "Food", type: "EXPENSE" },
  { id: 2, name: "Travel", type: "EXPENSE" },
];

/* ---------------- TESTS ---------------- */

describe("CategoriesPage", () => {

  beforeEach(() => {
    vi.clearAllMocks();
    api.get.mockResolvedValue({ data: mockCategories });
  });

  it("renders page title", async () => {
    render(
      <MemoryRouter>
        <CategoriesPage />
      </MemoryRouter>
    );

    expect(await screen.findByText(/My Categories/i))
      .toBeInTheDocument();
  });

  it("loads and displays categories", async () => {
    render(
      <MemoryRouter>
        <CategoriesPage />
      </MemoryRouter>
    );

    expect(await screen.findByRole("heading", { name: "Food" }))
      .toBeInTheDocument();

    expect(await screen.findByRole("heading", { name: "Travel" }))
      .toBeInTheDocument();
  });

  it("displays category type", async () => {
    render(
      <MemoryRouter>
        <CategoriesPage />
      </MemoryRouter>
    );

    expect(await screen.findAllByText(/EXPENSE/i))
      .toHaveLength(2);
  });

  it("shows empty state when no categories", async () => {
    api.get.mockResolvedValueOnce({ data: [] });

    render(
      <MemoryRouter>
        <CategoriesPage />
      </MemoryRouter>
    );

    expect(await screen.findByText(/No categories found/i))
      .toBeInTheDocument();
  });

  it("navigates back when back button clicked", async () => {
    render(
      <MemoryRouter>
        <CategoriesPage />
      </MemoryRouter>
    );

    const backBtn = await screen.findByText(/Back/i);
    fireEvent.click(backBtn);

    expect(mockNavigate).toHaveBeenCalledWith(-1);
  });

});