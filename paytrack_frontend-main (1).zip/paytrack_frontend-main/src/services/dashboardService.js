import api from "../api/axiosInstance";

// 🔥 Get all expenses
export const getExpenses = async () => {
  const res = await api.get("/expenses");
  return res.data;
};

// 🔥 Get dashboard summary (if you have report service)
export const getSummary = async () => {
  const res = await api.get("/reports/summary");
  return res.data;
};